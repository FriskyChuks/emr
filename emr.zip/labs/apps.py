from django.apps import AppConfig


class LabsConfig(AppConfig):
    name = 'labs'
