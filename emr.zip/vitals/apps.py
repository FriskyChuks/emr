from django.apps import AppConfig


class VitalsConfig(AppConfig):
    name = 'vitals'
