from django.contrib import admin

from .models import PatientVitalSigns


admin.site.register(PatientVitalSigns)
