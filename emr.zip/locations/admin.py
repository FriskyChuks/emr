from django.contrib import admin

from .models import Clinic, Ward


admin.site.register(Clinic)

admin.site.register(Ward)
