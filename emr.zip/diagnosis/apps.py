from django.apps import AppConfig


class DiagnosisConfig(AppConfig):
    name = 'diagnosis'
