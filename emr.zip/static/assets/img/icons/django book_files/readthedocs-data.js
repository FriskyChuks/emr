  var READTHEDOCS_DATA = {
    project: "django-book",
    version: "latest",
    language: "en",
    subprojects: {},
    canonical_url: "http://django-book.readthedocs.io/en/latest/",
    theme: "sphinx_rtd_theme",
    builder: "sphinx",
    docroot: "/en/",
    source_suffix: ".rst",
    api_host: "https://readthedocs.org",
    commit: "694e4a37"
  };
  