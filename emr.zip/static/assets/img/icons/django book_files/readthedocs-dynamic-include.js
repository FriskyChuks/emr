// RTD Analytics Code

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-17997319-1']);
_gaq.push(['_trackPageview']);


// User Analytics Code
_gaq.push(['user._setAccount', 'UA-1004202-6']);
_gaq.push(['user._trackPageview']);
// End User Analytics Code


(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

// end RTD Analytics Code
