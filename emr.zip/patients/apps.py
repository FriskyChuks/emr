from django.apps import AppConfig


class PatientsConfig(AppConfig):
    name = 'patients'
